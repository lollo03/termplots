from typing import List


def frange(start, stop, step=1.0):
    curr = float(start)
    tmp = []
    while curr < stop:
        tmp.append(round(curr, 8))
        curr += step
    tmp.append(float(stop))

    return tmp


def plot(iny: List, ystep=1, lowlim=None, highlim=None, car='*'):

    if lowlim == None:
        lowlim = min(iny)-ystep
    if highlim == None:
        highlim = max(iny)+ystep

    ndec = 0
    if type(ystep) == "float":
        ndec = len(str(ystep).split(".")[1])

    for y in reversed(frange(lowlim, highlim, ystep)):
        if(y >= 0):
            print(f' {y}|', end="")
        else:
            print(f'{y}|', end="")

        if(y == 0):
            for x in iny:
                if(round(x, ndec) == y):
                    print(car, end="")
                else:
                    print("--", end="")
        else:
            for x in iny:
                if(round(x, ndec) == y):
                    print(car, end="")
                else:
                    print("  ", end="")
        print("")

    print()


def mplot(iny: List, ystep=1, lowlim=None, highlim=None, car: List = ['*', '#', '@']):

    if lowlim == None:
        for serie in iny:
            if(iny[0] == serie):
                mymin = min(serie)
            elif(min(serie) < mymin):
                mymin = min(serie)
            lowlim = mymin - ystep
    if highlim == None:
        for serie in iny:
            if(iny[0] == serie):
                mymax = max(serie)
            elif(max(serie) > mymax):
                mymax = max(serie)
            highlim = mymax + ystep

    ndec = 0
    if type(ystep) == "float":
        ndec = len(str(ystep).split(".")[1])

    for y in reversed(frange(lowlim, highlim, ystep)):
        if(y >= 0):
            print(f' {y}|', end="")
        else:
            print(f'{y}|', end="")

        for serie in iny:
            if(y == 0):
                for x in serie:
                    if(round(x, ndec) == y):
                        print(car[iny.index(serie)], end="")
                    else:
                        print("--", end="")
            else:
                for x in serie:
                    if(round(x, ndec) == y):
                        print(car[iny.index(serie)], end="")
                    else:
                        print("  ", end="")
        print("")

    print()

